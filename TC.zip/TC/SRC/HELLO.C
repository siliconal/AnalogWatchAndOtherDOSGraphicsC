#include <stdio.h>
main()
{
	printf("Hello, World!");
        return(0);
}
