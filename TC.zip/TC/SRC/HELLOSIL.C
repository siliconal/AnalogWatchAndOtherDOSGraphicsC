#include <stdio.h>
#include <conio.h>
main()
{
	printf("Hello, World!");
	getch();
        return(0);
}
